"use client"

import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight, Send } from "lucide-react"

type Item = {
  title: string
  subtitle: string
  bullets: string[]
  image: string
  start: string
}

const ITEMS: Item[] = [
  {
    title: "Проекты для юрлиц под ключ",
    subtitle: "Широкоформатные чертежи • складывание под A4 • сшивка • сдача комплектом.",
    bullets: ["A2–A0+", "складывание под A4", "сшивка/папки/обложки"],
    image: "/banners/photo-wide.jpg",
    start: "biz_projects",
  },
  {
    title: "Печать A4/A3 (цвет/чб)",
    subtitle: "Быстро, аккуратно. Поможем с файлом и подскажем бумагу.",
    bullets: ["обычные документы", "двусторонняя", "скрепление/брошюровка"],
    image: "/banners/photo-cards.jpg",
    start: "a4_a3",
  },
  {
    title: "Постеры 100×70 + пенокартон",
    subtitle: "Матовая фотобумага + поклейка на пенокартон 3/5 мм. Идеально для архитекторов.",
    bullets: ["100×70", "матовая фото бумага", "пенокартон 3/5 мм"],
    image: "/banners/photo-wide.jpg",
    start: "foamboard_100x70",
  },
]

export function ServicesPreview() {
  const bot = process.env.NEXT_PUBLIC_TG_BOT ?? "cvetnoyPRINT"
  return (
    <section id="services" className="py-14 sm:py-16 border-b">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight">Три направления, где мы сильнее всего</h2>
            <p className="text-muted-foreground">Остальное тоже делаем — но это приносит максимум пользы (и денег).</p>
          </div>
          <Button asChild variant="outline" className="hidden sm:inline-flex gap-2">
            <a href="#assistant">
              Онлайн‑расчёт <ArrowRight className="h-4 w-4" />
            </a>
          </Button>
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-3">
          {ITEMS.map((p) => (
            <Card key={p.start} className="overflow-hidden">
              <div className="relative aspect-[16/10]">
                <Image src={p.image} alt={p.title} fill className="object-cover" priority />
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-background/10 to-transparent" />
              </div>
              <CardContent className="p-5 space-y-3">
                <div className="space-y-1">
                  <div className="font-semibold text-lg">{p.title}</div>
                  <p className="text-sm text-muted-foreground">{p.subtitle}</p>
                </div>

                <ul className="text-sm text-muted-foreground list-disc pl-5 space-y-1">
                  {p.bullets.map((b) => (
                    <li key={b}>{b}</li>
                  ))}
                </ul>

                <div className="pt-1 flex flex-col sm:flex-row gap-2">
                  <Button asChild className="gap-2">
                    <a href={`https://t.me/${bot}?start=from_site_${p.start}`}>
                      <Send className="h-4 w-4" />
                      Рассчитать в Telegram
                    </a>
                  </Button>
                  <Button asChild variant="outline" className="gap-2">
                    <a href="#assistant">
                      Онлайн‑расчёт <ArrowRight className="h-4 w-4" />
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-8 sm:hidden">
          <Button asChild variant="outline" className="w-full gap-2">
            <a href="#assistant">
              Онлайн‑расчёт <ArrowRight className="h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  )
}
