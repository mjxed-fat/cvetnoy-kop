"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X, Phone, MessageCircle, Send } from "lucide-react"
import { COMPANY } from "@/lib/site-data"

const nav = [
  { name: "Услуги", href: "/#services" },
  { name: "Примеры", href: "/#works" },
  { name: "Адреса", href: "/#branches" },
]

export function Header() {
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2 font-semibold tracking-tight">
            <span className="inline-block h-2.5 w-2.5 rounded-full bg-primary" aria-hidden />
            {COMPANY.name}
          </Link>

          <nav className="hidden md:flex items-center gap-6 text-sm">
            {nav.map((item) => (
              <Link key={item.href} href={item.href} className="text-muted-foreground hover:text-foreground transition">
                {item.name}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-2">
  <Button asChild className="gap-2">
    <a href={`https://t.me/${process.env.NEXT_PUBLIC_TG_BOT ?? "cvetnoyPRINT"}?start=from_site_header`}>
      <Send className="h-4 w-4" />
      Рассчитать в Telegram
    </a>
  </Button>
  <Button asChild variant="outline" className="gap-2">
    <a href="/#assistant">
      <MessageCircle className="h-4 w-4" />
      Онлайн‑расчёт
    </a>
  </Button>
  <Button asChild variant="ghost" className="gap-2">
    <a href={`tel:${COMPANY.phone.replace(/[^+\d]/g, "")}`}>
      <Phone className="h-4 w-4" />
      {COMPANY.phone}
    </a>
  </Button>
</div>

          <button
            className="md:hidden inline-flex h-10 w-10 items-center justify-center rounded-md border"
            onClick={() => setOpen((v) => !v)}
            aria-label="Открыть меню"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {open && (
          <div className="md:hidden pb-4">
            <div className="grid gap-2">
              {nav.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="rounded-md border px-3 py-2 text-sm"
                  onClick={() => setOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
              <a
                className="rounded-md border px-3 py-2 text-sm"
                href={`https://t.me/${process.env.NEXT_PUBLIC_TG_BOT ?? "cvetnoyPRINT"}?start=from_site_menu`}
                onClick={() => setOpen(false)}
              >
                Рассчитать в Telegram
              </a>
              <a className="rounded-md border px-3 py-2 text-sm" href="/#assistant" onClick={() => setOpen(false)}>
                Онлайн‑расчёт
              </a>
              <a className="rounded-md border px-3 py-2 text-sm" href={`tel:${COMPANY.phone.replace(/[^+\d]/g, "")}`}>
                {COMPANY.phone}
              </a>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
