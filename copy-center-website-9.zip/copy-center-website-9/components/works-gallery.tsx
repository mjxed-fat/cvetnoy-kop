import Image from "next/image"

const IMAGES = [
  { src: "/banners/photo-wide.jpg", alt: "Широкоформатная печать" },
  { src: "/banners/photo-stickers.jpg", alt: "Наклейки и резка по контуру" },
  { src: "/banners/photo-cards.jpg", alt: "Полиграфия и карточки" },
  { src: "/banners/photo-sublimation.jpg", alt: "Сублимация и сувениры" },
]

export function WorksGallery() {
  return (
    <section id="works" className="py-14 sm:py-16 border-y">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight">Примеры работ</h2>
            <p className="text-muted-foreground">Коротко и по делу — чтобы было понятно качество.</p>
          </div>
          <div className="text-sm text-muted-foreground hidden sm:block">Обновим галерею твоими фото</div>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {IMAGES.map((img) => (
            <div key={img.src} className="relative aspect-[4/3] overflow-hidden rounded-2xl border bg-muted/10">
              <Image src={img.src} alt={img.alt} fill className="object-cover" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
