import Link from "next/link"
import { COMPANY, BRANCHES } from "@/lib/site-data"

export function Footer() {
  return (
    <footer className="border-t">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid gap-8 md:grid-cols-3">
          <div className="space-y-2">
            <div className="font-semibold">{COMPANY.name}</div>
            <div className="text-sm text-muted-foreground">Печать, копирование и мини‑типография в {COMPANY.city}.</div>
            <div className="text-sm">
              <a className="underline underline-offset-4" href={`tel:${COMPANY.phone.replace(/[^+\d]/g, "")}`}>
                {COMPANY.phone}
              </a>
            </div>
            <div className="text-sm text-muted-foreground">{COMPANY.emails.join(" • ")}</div>
          </div>

          <div className="space-y-2">
            <div className="font-semibold">Разделы</div>
            <div className="grid gap-2 text-sm">
              <Link href="/services" className="text-muted-foreground hover:text-foreground">
                Услуги
              </Link>
              <Link href="/branches" className="text-muted-foreground hover:text-foreground">
                Филиалы
              </Link>
              <Link href="/contacts" className="text-muted-foreground hover:text-foreground">
                Контакты
              </Link>
              <a href="/#assistant" className="text-muted-foreground hover:text-foreground">
                Онлайн‑расчёт
              </a>
            </div>
          </div>

          <div className="space-y-2">
            <div className="font-semibold">Филиалы</div>
            <div className="grid gap-2 text-sm">
              {BRANCHES.map((b) => (
                <a key={b.id} className="text-muted-foreground hover:text-foreground" href={b.yandexMapsUrl} target="_blank">
                  {b.address}
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-10 text-xs text-muted-foreground">
          © {new Date().getFullYear()} {COMPANY.name}. Цены и сроки зависят от макета, материалов и тиража — точный расчёт
          делаем после уточнения деталей.
        </div>
      </div>
    </footer>
  )
}
