"use client"

import { useMemo, useRef, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { BRANCHES, SERVICES, type ServiceItem } from "@/lib/site-data"
import { MessageCircle, Send, Sparkles } from "lucide-react"
import Link from "next/link"

type Role = "assistant" | "user"

type ChatMsg = {
  role: Role
  text: string
}

type Draft = {
  serviceId?: string
  qty?: string
  format?: string
  material?: string
  size?: string
  deadline?: string
  branchId?: string
  contact?: string
  fileLink?: string
}

function serviceLabel(s: ServiceItem) {
  return s.title
}

export function SalesAssistant() {
  const [open, setOpen] = useState(true)
  const bot = process.env.NEXT_PUBLIC_TG_BOT ?? "cvetnoyPRINT"
  const [draft, setDraft] = useState<Draft>({})
  const [input, setInput] = useState("")
  const [step, setStep] = useState<
    "service" | "qty" | "format" | "material" | "size" | "deadline" | "branch" | "contact" | "done"
  >("service")

  const [messages, setMessages] = useState<ChatMsg[]>([
    {
      role: "assistant",
      text: "Привет! Я помогу рассчитать заказ. Что вам нужно сделать? Выберите услугу или напишите своими словами.",
    },
  ])

  const viewportRef = useRef<HTMLDivElement | null>(null)

  const quickServices = useMemo(() => {
    const ids = [
      "docs-print",
      "photo-docs",
      "stickers-printcut",
      "eco-solvent-print",
      "sublimation-mugs",
      "business-cards",
    ]
    return SERVICES.filter((s) => ids.includes(s.id))
  }, [])

  const selectedService = useMemo(
    () => SERVICES.find((s) => s.id === draft.serviceId),
    [draft.serviceId]
  )

  const scrollToBottom = () => {
    requestAnimationFrame(() => {
      if (!viewportRef.current) return
      viewportRef.current.scrollTop = viewportRef.current.scrollHeight
    })
  }

  const push = (role: Role, text: string) => {
    setMessages((m) => [...m, { role, text }])
    scrollToBottom()
  }

  const askNext = (nextStep: typeof step) => {
    setStep(nextStep)

    const prompts: Record<typeof step, string> = {
      service: "Что печатаем/делаем?",
      qty: "Сколько нужно? (тираж/кол-во страниц/штук)",
      format: "Какой формат? (например A4/A3/A0 или 90×50 и т.д.)",
      material: "Материал/основа? (бумага/плёнка/баннер/кружка/футболка)",
      size: "Размер/область печати? (если важно)",
      deadline: "Насколько срочно? (сегодня/к определённой дате)",
      branch: "Где удобнее забрать? (выберите филиал)",
      contact: "Как с вами связаться? (телефон/Telegram/WhatsApp)",
      done: "Готово",
    }

    if (nextStep === "branch") {
      push("assistant", prompts[nextStep])
      push(
        "assistant",
        "Подсказка: если нужен Print&Cut/широкоформат/сублимация — выбирайте филиал с оборудованием."
      )
      return
    }

    if (nextStep !== "done") push("assistant", prompts[nextStep])
  }

  const acceptFreeText = (text: string) => {
    // если шаг service и пользователь написал текст — подберём ближайшую услугу по ключевым словам
    if (step === "service") {
      const t = text.toLowerCase()
      const pick =
        SERVICES.find((s) => s.title.toLowerCase().includes(t)) ||
        (t.includes("накле") || t.includes("стик") ? SERVICES.find((s) => s.id === "stickers-printcut") : undefined) ||
        (t.includes("баннер") || t.includes("широк") ? SERVICES.find((s) => s.id === "eco-solvent-print") : undefined) ||
        (t.includes("круж") ? SERVICES.find((s) => s.id === "sublimation-mugs") : undefined) ||
        (t.includes("фото") ? SERVICES.find((s) => s.id === "photo-docs") : undefined) ||
        (t.includes("визит") ? SERVICES.find((s) => s.id === "business-cards") : undefined) ||
        SERVICES.find((s) => s.id === "docs-print")

      if (pick) {
        setDraft((d) => ({ ...d, serviceId: pick.id }))
        push("assistant", `Ок, похоже на: **${serviceLabel(pick)}**.`)
        askNext("qty")
        return
      }
    }

    // иначе просто сохраняем как значение текущего шага
    if (step === "qty") setDraft((d) => ({ ...d, qty: text }))
    if (step === "format") setDraft((d) => ({ ...d, format: text }))
    if (step === "material") setDraft((d) => ({ ...d, material: text }))
    if (step === "size") setDraft((d) => ({ ...d, size: text }))
    if (step === "deadline") setDraft((d) => ({ ...d, deadline: text }))
    if (step === "contact") setDraft((d) => ({ ...d, contact: text }))

    // шаги переходов
    const order: typeof step[] = ["service", "qty", "format", "material", "size", "deadline", "branch", "contact", "done"]
    const idx = order.indexOf(step)
    const next = order[Math.min(idx + 1, order.length - 1)]
    askNext(next)
  }

  const onSend = () => {
    const text = input.trim()
    if (!text) return
    setInput("")
    push("user", text)
    acceptFreeText(text)
  }

  const summary = useMemo(() => {
    const branch = BRANCHES.find((b) => b.id === draft.branchId)
    const parts = [
      selectedService ? `Услуга: ${selectedService.title}` : "",
      draft.qty ? `Количество: ${draft.qty}` : "",
      draft.format ? `Формат: ${draft.format}` : "",
      draft.material ? `Материал: ${draft.material}` : "",
      draft.size ? `Размер: ${draft.size}` : "",
      draft.deadline ? `Срок: ${draft.deadline}` : "",
      branch ? `Филиал: ${branch.address}` : "",
      draft.contact ? `Контакт: ${draft.contact}` : "",
    ].filter(Boolean)
    return parts.join(" • ")
  }, [draft, selectedService])

  const payUrl = useMemo(() => {
    const q = new URLSearchParams()
    if (selectedService) q.set("service", selectedService.title)
    if (draft.qty) q.set("qty", draft.qty)
    if (draft.format) q.set("format", draft.format)
    if (draft.material) q.set("material", draft.material)
    if (draft.size) q.set("size", draft.size)
    if (draft.deadline) q.set("deadline", draft.deadline)
    const branch = BRANCHES.find((b) => b.id === draft.branchId)
    if (branch) q.set("branch", branch.address)
    if (draft.contact) q.set("contact", draft.contact)
    return `/pay?${q.toString()}`
  }, [draft, selectedService])

  return (
    <section id="assistant" className="py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-3">
          <div className="space-y-1">
            <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight">Онлайн‑расчёт</h2>
            <p className="text-muted-foreground">
              Вместо перегруженного калькулятора — диалог. Я задам пару вопросов и соберу заявку на расчёт.
            </p>
          </div>
          <Button variant="outline" onClick={() => setOpen((v) => !v)}>
            <MessageCircle className="mr-2 h-4 w-4" />
            {open ? "Свернуть" : "Открыть"}
          </Button>
        </div>

        {open && (
          <Card className="mt-8 overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between gap-3">
              <div className="space-y-1">
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5" /> Помощник‑продавец
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Это интерфейс‑заготовка под ИИ‑агента. Позже подключим реальный расчёт и оплату.
                </p>
              </div>
              <div className="hidden sm:flex items-center gap-2">
                <Badge variant="secondary">быстро</Badge>
                <Badge variant="secondary">по делу</Badge>
                <Badge variant="secondary">без лишних полей</Badge>
              </div>
            </CardHeader>

            <CardContent className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
              <div className="rounded-lg border bg-background">
                <ScrollArea className="h-[420px]">
                  <div ref={viewportRef} className="p-4 space-y-3">
                    {messages.map((m, i) => (
                      <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                        <div
                          className={`max-w-[85%] rounded-2xl px-4 py-2 text-sm leading-relaxed ${
                            m.role === "user"
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted text-foreground"
                          }`}
                        >
                          {m.text}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
                <Separator />
                <div className="p-3 flex gap-2">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Напишите ответ…"
                    onKeyDown={(e) => {
                      if (e.key === "Enter") onSend()
                    }}
                  />
                  <Button onClick={onSend}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Быстрый старт</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <p className="text-sm text-muted-foreground">Нажмите услугу — и пойдём по вопросам.</p>
                    <div className="flex flex-wrap gap-2">
                      {quickServices.map((s) => (
                        <Button
                          key={s.id}
                          size="sm"
                          variant={draft.serviceId === s.id ? "default" : "outline"}
                          onClick={() => {
                            setDraft((d) => ({ ...d, serviceId: s.id }))
                            push("user", s.title)
                            askNext("qty")
                          }}
                        >
                          {s.title}
                        </Button>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Выбор филиала</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <p className="text-sm text-muted-foreground">Можно выбрать сразу — или позже.</p>
                    <div className="grid gap-2">
                      {BRANCHES.map((b) => (
                        <Button
                          key={b.id}
                          variant={draft.branchId === b.id ? "default" : "outline"}
                          className="justify-start h-auto py-3"
                          onClick={() => {
                            setDraft((d) => ({ ...d, branchId: b.id }))
                            push("user", `Филиал: ${b.address}`)
                            if (step === "branch") askNext("contact")
                          }}
                        >
                          <div className="text-left">
                            <div className="font-medium">{b.name}</div>
                            <div className="text-xs text-muted-foreground">{b.address}</div>
                          </div>
                        </Button>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Итог и оплата</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      Итог формируется из ответов. Реальный расчёт и оплата подключаются на следующем этапе.
                    </p>
                    <div className="rounded-lg border bg-muted/30 p-3 text-sm">
                      {summary ? summary : "Пока пусто — начните диалог."}
                    </div>
                    <div className="flex flex-col sm:flex-row gap-2">
  <Button asChild disabled={!summary} className="gap-2">
    <a href={`https://t.me/${bot}?start=lead_${summary ? summary.length : 0}`}>
      <Send className="h-4 w-4" />
      Отправить в Telegram
    </a>
  </Button>
  <Button asChild variant="outline" disabled={!summary} className="gap-2">
    <Link href={payUrl}>Оплатить</Link>
  </Button>
</div>
<p className="text-xs text-muted-foreground">
  Telegram отправит менеджеру готовый бриф. Оплата — тестовая страница (ЮKassa подключим следующим шагом).
</p>

                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </section>
  )
}
