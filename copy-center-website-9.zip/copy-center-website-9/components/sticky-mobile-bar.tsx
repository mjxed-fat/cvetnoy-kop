"use client"

import { useMemo } from "react"
import { Send, CreditCard, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"

export function StickyMobileBar() {
  const bot = process.env.NEXT_PUBLIC_TG_BOT ?? "cvetnoyPRINT"
  const tgLink = useMemo(() => `https://t.me/${bot}?start=from_site_sticky`, [bot])

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 border-t bg-background/85 backdrop-blur md:hidden">
      <div className="mx-auto max-w-7xl px-4 py-2">
        <div className="grid grid-cols-3 gap-2">
          <Button asChild className="gap-2 h-11">
            <a href={tgLink}>
              <Send className="h-4 w-4" />
              Telegram
            </a>
          </Button>
          <Button asChild variant="outline" className="gap-2 h-11">
            <a href="/#assistant">
              <CreditCard className="h-4 w-4" />
              Оплатить
            </a>
          </Button>
          <Button asChild variant="outline" className="gap-2 h-11">
            <a href="/#branches">
              <MapPin className="h-4 w-4" />
              Адреса
            </a>
          </Button>
        </div>
      </div>
    </div>
  )
}
