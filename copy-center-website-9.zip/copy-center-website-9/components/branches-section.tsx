import { BRANCHES } from "@/lib/site-data"
import { Card, CardContent } from "@/components/ui/card"
import { MapPin, Clock, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"

export function BranchesSection() {
  return (
    <section id="branches" className="py-14 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="space-y-1">
          <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight">Филиалы</h2>
          <p className="text-muted-foreground">Выбирай, где удобнее забрать заказ.</p>
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-3">
          {BRANCHES.map((b) => (
            <Card key={b.id}>
              <CardContent className="p-6 space-y-4">
                <div>
                  <div className="font-semibold">{b.name}</div>
                  <div className="mt-2 flex items-start gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4 mt-0.5" />
                    <span>{b.address}</span>
                  </div>
                  <div className="mt-2 flex items-start gap-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4 mt-0.5" />
                    <span>{b.hours}</span>
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  <Button asChild variant="outline" className="gap-2">
                    <a href={b.yandexMapsUrl} target="_blank" rel="noreferrer">
                      Открыть на карте
                    </a>
                  </Button>
                  <Button asChild variant="ghost" className="gap-2 justify-start">
                    <a href={`tel:${b.phone.replace(/[^+\d]/g, "")}`}>
                      <Phone className="h-4 w-4" />
                      {b.phone}
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
