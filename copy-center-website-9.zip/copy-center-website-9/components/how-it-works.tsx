import { Card, CardContent } from "@/components/ui/card"
import { Upload, CheckCircle2, Printer } from "lucide-react"

const STEPS = [
  {
    title: "Отправляете файл",
    text: "В Telegram боту или через онлайн‑расчёт. Можно ссылкой на диск.",
    icon: Upload,
  },
  {
    title: "Проверяем и согласуем",
    text: "Формат, поля, качество. Если нужно — подскажем материал и тираж.",
    icon: CheckCircle2,
  },
  {
    title: "Печатаем и выдаём",
    text: "Быстро и аккуратно. Для проектов — складывание под A4 и сшивка.",
    icon: Printer,
  },
]

export function HowItWorks() {
  return (
    <section className="py-14 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="space-y-1">
          <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight">Как это работает</h2>
          <p className="text-muted-foreground">Три шага — и заказ уже в печати.</p>
        </div>

        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {STEPS.map((s) => (
            <Card key={s.title}>
              <CardContent className="p-6 space-y-3">
                <div className="inline-flex h-11 w-11 items-center justify-center rounded-xl border bg-muted/20">
                  <s.icon className="h-5 w-5" />
                </div>
                <div className="font-semibold">{s.title}</div>
                <div className="text-sm text-muted-foreground">{s.text}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
