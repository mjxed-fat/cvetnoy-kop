"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { COMPANY } from "@/lib/site-data"
import { ArrowRight, Phone } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden border-b bg-background">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,hsl(var(--muted))_0%,transparent_55%)]" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14 sm:py-20">
        <div className="grid gap-10 lg:grid-cols-[1.1fr_0.9fr] items-center">
          <div className="space-y-6">
            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary">Проекты для юрлиц под ключ</Badge>
              <Badge variant="secondary">A4/A3 • цвет/чб</Badge>
              <Badge variant="secondary">100×70 • пенокартон</Badge>
            </div>

                        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight text-balance">
              Печать <span className="text-cyan-400 [text-shadow:0_0_14px_rgba(34,211,238,0.55)]">«Цветной»</span> — быстро, аккуратно, по делу
            </h1>

            <p className="text-lg text-muted-foreground max-w-xl">
              Юрлица — проекты под ключ (широкоформат, складывание под A4, сшивка). Быстрая печать A4/A3. Постеры 100×70 на матовой фотобумаге с поклейкой на пенокартон.
            </p>

            <div className="flex flex-col sm:flex-row gap-3">
  <Button asChild size="lg" className="gap-2">
    <a href={`https://t.me/${process.env.NEXT_PUBLIC_TG_BOT ?? "cvetnoyPRINT"}?start=from_site_hero`}>
      Рассчитать в Telegram <ArrowRight className="h-4 w-4" />
    </a>
  </Button>
  <Button asChild size="lg" variant="outline" className="gap-2">
    <a href="#assistant">
      Онлайн‑расчёт <ArrowRight className="h-4 w-4" />
    </a>
  </Button>
</div>

            <div className="text-sm text-muted-foreground">
              Ответ в Telegram обычно до 10 минут • 3 филиала в Казани
            </div>
</div>

          </div>

          <div className="rounded-2xl border bg-muted/20 overflow-hidden">
            <div className="relative aspect-[16/10]">
              <Image
                src="/banners/photo-wide.jpg"
                alt="Широкоформатная печать и мини-типография"
                fill
                className="object-cover"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/75 via-background/10 to-transparent" />
            </div>

            <div className="p-4 sm:p-6">
              <div className="text-sm font-medium">Топ‑заказы</div>
              <div className="mt-4 grid gap-3">
                <div className="rounded-xl border bg-background p-4">
                  <div className="font-medium">Проекты под ключ для юрлиц</div>
                  <div className="text-sm text-muted-foreground">Широкоформат • складывание под A4 • сшивка</div>
                </div>
                <div className="rounded-xl border bg-background p-4">
                  <div className="font-medium">Печать A4/A3</div>
                  <div className="text-sm text-muted-foreground">Цветная и ч/б • быстро • с проверкой файла</div>
                </div>
                <div className="rounded-xl border bg-background p-4">
                  <div className="font-medium">100×70 на пенокартоне</div>
                  <div className="text-sm text-muted-foreground">Матовая фотобумага + поклейка • для архитекторов</div>
                </div>
              </div>
                  <div className="text-sm text-muted-foreground">Печать + резка по контуру. Стикерпаки, этикетки.</div>
                </div>
                <div className="rounded-xl border bg-background p-4">
                  <div className="font-medium">Широкоформат до 160 см</div>
                  <div className="text-sm text-muted-foreground">Баннеры, плёнка, плакаты, схемы A2–A0.</div>
                </div>
                <div className="rounded-xl border bg-background p-4">
                  <div className="font-medium">Сублимация</div>
                  <div className="text-sm text-muted-foreground">Кружки и белый текстиль с вашим дизайном.</div>
                </div>
              </div>

              <div className="mt-5 flex items-center justify-between rounded-xl bg-background/60 p-4">
                <div>
                  <div className="text-sm text-muted-foreground">Менеджер в Telegram</div>
                  <div className="font-medium">@cvetnoy16</div>
                </div>
                <Button asChild variant="outline" className="gap-2">
                  <a href="/#branches">
                    Адреса <ArrowRight className="h-4 w-4" />
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
