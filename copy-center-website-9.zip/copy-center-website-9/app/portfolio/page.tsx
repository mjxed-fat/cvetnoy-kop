"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Briefcase, Eye, ArrowRight, Filter } from "lucide-react"
import Link from "next/link"

const portfolioItems = [
  {
    id: 1,
    title: "Корпоративные визитки для IT-компании",
    category: "Визитки",
    image: "/modern-business-cards-design.jpg",
    description: "Минималистичный дизайн визиток с использованием премиальной бумаги и УФ-лака",
    tags: ["Визитки", "Дизайн", "УФ-лак"],
    client: "TechCorp",
  },
  {
    id: 2,
    title: "Рекламные баннеры для ресторана",
    category: "Широкоформат",
    image: "/restaurant-advertising-banners.jpg",
    description: "Яркие баннеры для летней террасы ресторана с водостойкой печатью",
    tags: ["Баннеры", "Реклама", "Водостойкая печать"],
    client: "Ресторан Вкус",
  },
  {
    id: 3,
    title: "Каталог мебельной компании",
    category: "Полиграфия",
    image: "/furniture-catalog-design.jpg",
    description: "48-страничный каталог с качественной фотосъемкой и профессиональной версткой",
    tags: ["Каталог", "Верстка", "Фотосъемка"],
    client: "МебельДом",
  },
  {
    id: 4,
    title: "Упаковка для косметического бренда",
    category: "Упаковка",
    image: "/cosmetic-packaging-design.jpg",
    description: "Элегантная упаковка с тиснением фольгой и soft-touch покрытием",
    tags: ["Упаковка", "Тиснение", "Soft-touch"],
    client: "BeautyLine",
  },
  {
    id: 5,
    title: "Фирменные блокноты и ежедневники",
    category: "Полиграфия",
    image: "/corporate-notebooks-design.jpg",
    description: "Серия корпоративных блокнотов с логотипом компании и индивидуальным дизайном",
    tags: ["Блокноты", "Корпоративный стиль", "Переплет"],
    client: "Строй Альянс",
  },
  {
    id: 6,
    title: "Наклейки для маркетплейса",
    category: "Наклейки",
    image: "/marketplace-product-stickers.jpg",
    description: "Водостойкие наклейки для товаров с QR-кодами и штрих-кодами",
    tags: ["Наклейки", "QR-коды", "Водостойкие"],
    client: "OnlineShop",
  },
]

const categories = ["Все", "Визитки", "Широкоформат", "Полиграфия", "Упаковка", "Наклейки"]

export default function PortfolioPage() {
  const [isVisible, setIsVisible] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState("Все")
  const [filteredItems, setFilteredItems] = useState(portfolioItems)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  useEffect(() => {
    if (selectedCategory === "Все") {
      setFilteredItems(portfolioItems)
    } else {
      setFilteredItems(portfolioItems.filter((item) => item.category === selectedCategory))
    }
  }, [selectedCategory])

  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-br from-background via-background to-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`text-center space-y-6 ${isVisible ? "animate-fade-in-up" : "opacity-0"}`}>
            <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto">
              <Briefcase className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground text-balance">Наше портфолио</h1>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Примеры наших работ — от визиток до крупных рекламных кампаний. Каждый проект выполнен с вниманием к
              деталям и высоким качеством печати.
            </p>
          </div>
        </div>
      </section>

      {/* Filter Section */}
      <section className="py-8 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div
            className={`flex items-center space-x-4 ${isVisible ? "animate-fade-in-up animate-delay-200" : "opacity-0"}`}
          >
            <Filter className="w-5 h-5 text-muted-foreground" />
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className={selectedCategory !== category ? "bg-transparent" : ""}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div
            className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 ${isVisible ? "animate-fade-in-up animate-delay-300" : "opacity-0"}`}
          >
            {filteredItems.map((item, index) => (
              <Card
                key={item.id}
                className="group hover:shadow-xl transition-all duration-300 border-0 bg-card/50 backdrop-blur-sm overflow-hidden"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={item.image || "/placeholder.svg"}
                    alt={item.title}
                    className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300 flex items-center justify-center">
                    <Button
                      size="sm"
                      className="opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      variant="secondary"
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      Посмотреть
                    </Button>
                  </div>
                </div>

                <CardContent className="p-6 space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary" className="text-xs">
                        {item.category}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{item.client}</span>
                    </div>
                    <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                      {item.title}
                    </h3>
                    <p className="text-sm text-muted-foreground text-pretty">{item.description}</p>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {item.tags.map((tag, tagIndex) => (
                      <Badge key={tagIndex} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className={`space-y-6 ${isVisible ? "animate-fade-in-up animate-delay-400" : "opacity-0"}`}>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground text-balance">
              Готовы создать что-то особенное?
            </h2>
            <p className="text-lg text-muted-foreground text-pretty">
              Обсудим ваш проект и предложим лучшие решения для воплощения ваших идей в жизнь
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link href="/contacts">
                  Обсудить проект
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link href="/calculators">Рассчитать стоимость</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
