"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Calculator, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function BusinessCardsCalculatorPage() {
  const [format, setFormat] = useState("")
  const [paper, setPaper] = useState("")
  const [quantity, setQuantity] = useState("500")
  const [sides, setSides] = useState("2")
  const [finishing, setFinishing] = useState<string[]>([])

  const formats = [
    { value: "90x50", label: "90×50 мм (стандарт)", price: 1.0 },
    { value: "85x55", label: "85×55 мм (европейский)", price: 1.0 },
    { value: "90x55", label: "90×55 мм (американский)", price: 1.1 },
  ]

  const papers = [
    { value: "offset300", label: "Офсет 300 г/м²", price: 1.0 },
    { value: "coated350", label: "Мелованная 350 г/м²", price: 1.2 },
    { value: "textured300", label: "Дизайнерская 300 г/м²", price: 1.5 },
    { value: "plastic", label: "Пластик 0.76 мм", price: 2.5 },
  ]

  const finishingOptions = [
    { id: "lamination", label: "Ламинация матовая", price: 0.5 },
    { id: "lamination-gloss", label: "Ламинация глянцевая", price: 0.5 },
    { id: "uv", label: "УФ-лак выборочный", price: 1.2 },
    { id: "foil", label: "Тиснение фольгой", price: 2.0 },
    { id: "emboss", label: "Конгревное тиснение", price: 1.8 },
    { id: "round-corners", label: "Скругленные углы", price: 0.3 },
  ]

  const quantityPrices = {
    "100": 8.0,
    "250": 4.5,
    "500": 3.0,
    "1000": 2.2,
    "2000": 1.8,
    "5000": 1.4,
  }

  const calculatePrice = () => {
    if (!format || !paper || !quantity) return 0

    const selectedFormat = formats.find((f) => f.value === format)
    const selectedPaper = papers.find((p) => p.value === paper)
    const basePrice = quantityPrices[quantity as keyof typeof quantityPrices]

    if (!selectedFormat || !selectedPaper || !basePrice) return 0

    let totalPrice = Number.parseInt(quantity) * basePrice * selectedFormat.price * selectedPaper.price

    // Добавляем стоимость за двустороннюю печать
    if (sides === "2") {
      totalPrice *= 1.4
    }

    // Добавляем стоимость постпечатной обработки
    finishing.forEach((finishId) => {
      const option = finishingOptions.find((f) => f.id === finishId)
      if (option) {
        totalPrice += Number.parseInt(quantity) * option.price
      }
    })

    return Math.round(totalPrice)
  }

  const handleFinishingChange = (finishId: string, checked: boolean) => {
    if (checked) {
      setFinishing([...finishing, finishId])
    } else {
      setFinishing(finishing.filter((id) => id !== finishId))
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto py-16 px-4">
        <div className="mb-8">
          <Link href="/calculators" className="inline-flex items-center gap-2 text-primary hover:underline mb-4">
            <ArrowLeft className="w-4 h-4" />
            Назад к калькуляторам
          </Link>
          <h1 className="text-4xl font-bold text-foreground mb-4">Калькулятор визиток и листовок</h1>
          <p className="text-lg text-muted-foreground">Рассчитайте стоимость печати визиток, листовок и буклетов</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calculator Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="w-5 h-5" />
                  Параметры заказа
                </CardTitle>
                <CardDescription>Выберите формат, бумагу и дополнительные опции</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Формат */}
                <div className="space-y-2">
                  <Label>Формат</Label>
                  <Select value={format} onValueChange={setFormat}>
                    <SelectTrigger>
                      <SelectValue placeholder="Выберите формат" />
                    </SelectTrigger>
                    <SelectContent>
                      {formats.map((fmt) => (
                        <SelectItem key={fmt.value} value={fmt.value}>
                          {fmt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Бумага */}
                <div className="space-y-2">
                  <Label>Тип бумаги</Label>
                  <Select value={paper} onValueChange={setPaper}>
                    <SelectTrigger>
                      <SelectValue placeholder="Выберите бумагу" />
                    </SelectTrigger>
                    <SelectContent>
                      {papers.map((p) => (
                        <SelectItem key={p.value} value={p.value}>
                          {p.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Количество */}
                <div className="space-y-2">
                  <Label>Количество</Label>
                  <Select value={quantity} onValueChange={setQuantity}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(quantityPrices).map(([qty, price]) => (
                        <SelectItem key={qty} value={qty}>
                          {qty} шт - {price} ₽/шт
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Печать */}
                <div className="space-y-2">
                  <Label>Печать</Label>
                  <Select value={sides} onValueChange={setSides}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">Односторонняя</SelectItem>
                      <SelectItem value="2">Двусторонняя (+40%)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Постпечатная обработка */}
                <div className="space-y-3">
                  <Label>Постпечатная обработка</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {finishingOptions.map((option) => (
                      <div key={option.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={option.id}
                          checked={finishing.includes(option.id)}
                          onCheckedChange={(checked) => handleFinishingChange(option.id, checked as boolean)}
                        />
                        <Label htmlFor={option.id} className="text-sm">
                          {option.label} (+{option.price} ₽/шт)
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Price Summary */}
          <div>
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle>Расчет стоимости</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Печать:</span>
                    <span>
                      {calculatePrice() > 0
                        ? `${Math.round(
                            calculatePrice() -
                              finishing.reduce((sum, finishId) => {
                                const option = finishingOptions.find((f) => f.id === finishId)
                                return sum + (option ? option.price * Number.parseInt(quantity) : 0)
                              }, 0),
                          )} ₽`
                        : "0 ₽"}
                    </span>
                  </div>

                  {finishing.length > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>Обработка:</span>
                      <span>
                        {finishing.reduce((sum, finishId) => {
                          const option = finishingOptions.find((f) => f.id === finishId)
                          return sum + (option ? option.price * Number.parseInt(quantity) : 0)
                        }, 0)}{" "}
                        ₽
                      </span>
                    </div>
                  )}
                </div>

                <div className="border-t pt-4">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold">Итого:</span>
                    <span className="text-2xl font-bold text-primary">{calculatePrice()} ₽</span>
                  </div>
                </div>

                <div className="text-xs text-muted-foreground">* Срок изготовления: 1-2 рабочих дня</div>

                <Button className="w-full" disabled={calculatePrice() === 0}>
                  Заказать печать
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
