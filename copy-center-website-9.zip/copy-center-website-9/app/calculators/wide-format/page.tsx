"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Calculator, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function WideFormatCalculatorPage() {
  const [width, setWidth] = useState("")
  const [height, setHeight] = useState("")
  const [material, setMaterial] = useState("")
  const [quantity, setQuantity] = useState("1")
  const [finishing, setFinishing] = useState<string[]>([])
  const [installation, setInstallation] = useState(false)

  const materials = [
    { value: "banner", label: "Баннерная ткань", price: 350 },
    { value: "vinyl", label: "Самоклеящаяся пленка", price: 450 },
    { value: "canvas", label: "Холст", price: 650 },
    { value: "paper", label: "Фотобумага", price: 280 },
    { value: "mesh", label: "Сетка (mesh)", price: 320 },
  ]

  const finishingOptions = [
    { id: "eyelets", label: "Люверсы", price: 50 },
    { id: "welding", label: "Проварка швов", price: 80 },
    { id: "cutting", label: "Фигурная резка", price: 120 },
    { id: "lamination", label: "Ламинация", price: 200 },
  ]

  const calculatePrice = () => {
    if (!width || !height || !material) return 0

    const area = (Number.parseFloat(width) * Number.parseFloat(height)) / 10000 // в м²
    const selectedMaterial = materials.find((m) => m.value === material)
    if (!selectedMaterial) return 0

    let basePrice = area * selectedMaterial.price * Number.parseInt(quantity)

    // Добавляем стоимость постпечатной обработки
    finishing.forEach((finishId) => {
      const option = finishingOptions.find((f) => f.id === finishId)
      if (option) {
        basePrice += option.price * Number.parseInt(quantity)
      }
    })

    // Добавляем монтаж
    if (installation) {
      basePrice += area * 150 * Number.parseInt(quantity)
    }

    return Math.round(basePrice)
  }

  const handleFinishingChange = (finishId: string, checked: boolean) => {
    if (checked) {
      setFinishing([...finishing, finishId])
    } else {
      setFinishing(finishing.filter((id) => id !== finishId))
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto py-16 px-4">
        <div className="mb-8">
          <Link href="/calculators" className="inline-flex items-center gap-2 text-primary hover:underline mb-4">
            <ArrowLeft className="w-4 h-4" />
            Назад к калькуляторам
          </Link>
          <h1 className="text-4xl font-bold text-foreground mb-4">Калькулятор широкоформатной печати</h1>
          <p className="text-lg text-muted-foreground">
            Рассчитайте стоимость печати баннеров, постеров и других материалов большого формата
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calculator Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="w-5 h-5" />
                  Параметры заказа
                </CardTitle>
                <CardDescription>Укажите размеры и характеристики вашего заказа</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Размеры */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="width">Ширина (см)</Label>
                    <Input
                      id="width"
                      type="number"
                      placeholder="100"
                      value={width}
                      onChange={(e) => setWidth(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="height">Высота (см)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="200"
                      value={height}
                      onChange={(e) => setHeight(e.target.value)}
                    />
                  </div>
                </div>

                {/* Материал */}
                <div className="space-y-2">
                  <Label>Материал</Label>
                  <Select value={material} onValueChange={setMaterial}>
                    <SelectTrigger>
                      <SelectValue placeholder="Выберите материал" />
                    </SelectTrigger>
                    <SelectContent>
                      {materials.map((mat) => (
                        <SelectItem key={mat.value} value={mat.value}>
                          {mat.label} - {mat.price} ₽/м²
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Количество */}
                <div className="space-y-2">
                  <Label htmlFor="quantity">Количество</Label>
                  <Input
                    id="quantity"
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                  />
                </div>

                {/* Постпечатная обработка */}
                <div className="space-y-3">
                  <Label>Постпечатная обработка</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {finishingOptions.map((option) => (
                      <div key={option.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={option.id}
                          checked={finishing.includes(option.id)}
                          onCheckedChange={(checked) => handleFinishingChange(option.id, checked as boolean)}
                        />
                        <Label htmlFor={option.id} className="text-sm">
                          {option.label} (+{option.price} ₽)
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Монтаж */}
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="installation"
                    checked={installation}
                    onCheckedChange={(checked) => setInstallation(checked as boolean)}
                  />
                  <Label htmlFor="installation">Монтаж (+150 ₽/м²)</Label>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Price Summary */}
          <div>
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle>Расчет стоимости</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {width && height && (
                  <div className="text-sm text-muted-foreground">
                    Площадь: {((Number.parseFloat(width) * Number.parseFloat(height)) / 10000).toFixed(2)} м²
                  </div>
                )}

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Печать:</span>
                    <span>
                      {calculatePrice() > 0
                        ? `${Math.round(
                            calculatePrice() -
                              finishing.reduce((sum, finishId) => {
                                const option = finishingOptions.find((f) => f.id === finishId)
                                return sum + (option ? option.price * Number.parseInt(quantity) : 0)
                              }, 0) -
                              (installation && width && height
                                ? ((Number.parseFloat(width) * Number.parseFloat(height)) / 10000) *
                                  150 *
                                  Number.parseInt(quantity)
                                : 0),
                          )} ₽`
                        : "0 ₽"}
                    </span>
                  </div>

                  {finishing.length > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>Обработка:</span>
                      <span>
                        {finishing.reduce((sum, finishId) => {
                          const option = finishingOptions.find((f) => f.id === finishId)
                          return sum + (option ? option.price * Number.parseInt(quantity) : 0)
                        }, 0)}{" "}
                        ₽
                      </span>
                    </div>
                  )}

                  {installation && width && height && (
                    <div className="flex justify-between text-sm">
                      <span>Монтаж:</span>
                      <span>
                        {Math.round(
                          ((Number.parseFloat(width) * Number.parseFloat(height)) / 10000) *
                            150 *
                            Number.parseInt(quantity),
                        )}{" "}
                        ₽
                      </span>
                    </div>
                  )}
                </div>

                <div className="border-t pt-4">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold">Итого:</span>
                    <span className="text-2xl font-bold text-primary">{calculatePrice()} ₽</span>
                  </div>
                </div>

                <div className="text-xs text-muted-foreground">* Срок изготовления: 1-3 рабочих дня</div>

                <Button className="w-full" disabled={calculatePrice() === 0}>
                  Заказать печать
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
