"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Calculator, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function StickersCalculatorPage() {
  const [format, setFormat] = useState("")
  const [material, setMaterial] = useState("")
  const [quantity, setQuantity] = useState("100")
  const [shape, setShape] = useState("rectangle")
  const [finishing, setFinishing] = useState<string[]>([])
  const [customWidth, setCustomWidth] = useState("")
  const [customHeight, setCustomHeight] = useState("")

  const formats = [
    { value: "50x30", label: "50×30 мм", price: 1.0 },
    { value: "70x50", label: "70×50 мм", price: 1.2 },
    { value: "100x70", label: "100×70 мм", price: 1.5 },
    { value: "custom", label: "Произвольный размер", price: 1.0 },
  ]

  const materials = [
    { value: "paper", label: "Бумага самоклеящаяся", price: 1.0 },
    { value: "vinyl", label: "Виниловая пленка", price: 1.8 },
    { value: "transparent", label: "Прозрачная пленка", price: 2.2 },
    { value: "hologram", label: "Голографическая пленка", price: 3.5 },
  ]

  const shapes = [
    { value: "rectangle", label: "Прямоугольные", price: 1.0 },
    { value: "round", label: "Круглые", price: 1.1 },
    { value: "oval", label: "Овальные", price: 1.2 },
    { value: "custom", label: "Фигурная высечка", price: 1.8 },
  ]

  const finishingOptions = [
    { id: "lamination", label: "Ламинация", price: 0.8 },
    { id: "uv", label: "УФ-лак", price: 1.2 },
    { id: "foil", label: "Фольгирование", price: 2.5 },
    { id: "numbering", label: "Нумерация", price: 0.5 },
  ]

  const quantityPrices = {
    "50": 12.0,
    "100": 8.0,
    "250": 5.5,
    "500": 4.0,
    "1000": 3.2,
    "2000": 2.8,
    "5000": 2.2,
  }

  const calculatePrice = () => {
    if (!format || !material || !quantity) return 0

    const selectedFormat = formats.find((f) => f.value === format)
    const selectedMaterial = materials.find((m) => m.value === material)
    const selectedShape = shapes.find((s) => s.value === shape)
    const basePrice = quantityPrices[quantity as keyof typeof quantityPrices]

    if (!selectedFormat || !selectedMaterial || !selectedShape || !basePrice) return 0

    let totalPrice =
      Number.parseInt(quantity) * basePrice * selectedFormat.price * selectedMaterial.price * selectedShape.price

    // Для произвольного размера добавляем наценку
    if (format === "custom" && customWidth && customHeight) {
      const area = (Number.parseFloat(customWidth) * Number.parseFloat(customHeight)) / 10000 // в м²
      totalPrice *= Math.max(1, area * 100) // минимум 1, иначе по площади
    }

    // Добавляем стоимость постпечатной обработки
    finishing.forEach((finishId) => {
      const option = finishingOptions.find((f) => f.id === finishId)
      if (option) {
        totalPrice += Number.parseInt(quantity) * option.price
      }
    })

    return Math.round(totalPrice)
  }

  const handleFinishingChange = (finishId: string, checked: boolean) => {
    if (checked) {
      setFinishing([...finishing, finishId])
    } else {
      setFinishing(finishing.filter((id) => id !== finishId))
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto py-16 px-4">
        <div className="mb-8">
          <Link href="/calculators" className="inline-flex items-center gap-2 text-primary hover:underline mb-4">
            <ArrowLeft className="w-4 h-4" />
            Назад к калькуляторам
          </Link>
          <h1 className="text-4xl font-bold text-foreground mb-4">Калькулятор наклеек и этикеток</h1>
          <p className="text-lg text-muted-foreground">Рассчитайте стоимость печати наклеек, этикеток и стикеров</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calculator Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="w-5 h-5" />
                  Параметры заказа
                </CardTitle>
                <CardDescription>Выберите размер, материал и форму наклеек</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Формат */}
                <div className="space-y-2">
                  <Label>Размер</Label>
                  <Select value={format} onValueChange={setFormat}>
                    <SelectTrigger>
                      <SelectValue placeholder="Выберите размер" />
                    </SelectTrigger>
                    <SelectContent>
                      {formats.map((fmt) => (
                        <SelectItem key={fmt.value} value={fmt.value}>
                          {fmt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Произвольный размер */}
                {format === "custom" && (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="customWidth">Ширина (мм)</Label>
                      <Input
                        id="customWidth"
                        type="number"
                        placeholder="50"
                        value={customWidth}
                        onChange={(e) => setCustomWidth(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="customHeight">Высота (мм)</Label>
                      <Input
                        id="customHeight"
                        type="number"
                        placeholder="30"
                        value={customHeight}
                        onChange={(e) => setCustomHeight(e.target.value)}
                      />
                    </div>
                  </div>
                )}

                {/* Материал */}
                <div className="space-y-2">
                  <Label>Материал</Label>
                  <Select value={material} onValueChange={setMaterial}>
                    <SelectTrigger>
                      <SelectValue placeholder="Выберите материал" />
                    </SelectTrigger>
                    <SelectContent>
                      {materials.map((mat) => (
                        <SelectItem key={mat.value} value={mat.value}>
                          {mat.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Форма */}
                <div className="space-y-2">
                  <Label>Форма</Label>
                  <Select value={shape} onValueChange={setShape}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {shapes.map((s) => (
                        <SelectItem key={s.value} value={s.value}>
                          {s.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Количество */}
                <div className="space-y-2">
                  <Label>Количество</Label>
                  <Select value={quantity} onValueChange={setQuantity}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(quantityPrices).map(([qty, price]) => (
                        <SelectItem key={qty} value={qty}>
                          {qty} шт - {price} ₽/шт
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Постпечатная обработка */}
                <div className="space-y-3">
                  <Label>Дополнительные опции</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {finishingOptions.map((option) => (
                      <div key={option.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={option.id}
                          checked={finishing.includes(option.id)}
                          onCheckedChange={(checked) => handleFinishingChange(option.id, checked as boolean)}
                        />
                        <Label htmlFor={option.id} className="text-sm">
                          {option.label} (+{option.price} ₽/шт)
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Price Summary */}
          <div>
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle>Расчет стоимости</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Печать:</span>
                    <span>
                      {calculatePrice() > 0
                        ? `${Math.round(
                            calculatePrice() -
                              finishing.reduce((sum, finishId) => {
                                const option = finishingOptions.find((f) => f.id === finishId)
                                return sum + (option ? option.price * Number.parseInt(quantity) : 0)
                              }, 0),
                          )} ₽`
                        : "0 ₽"}
                    </span>
                  </div>

                  {finishing.length > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>Опции:</span>
                      <span>
                        {finishing.reduce((sum, finishId) => {
                          const option = finishingOptions.find((f) => f.id === finishId)
                          return sum + (option ? option.price * Number.parseInt(quantity) : 0)
                        }, 0)}{" "}
                        ₽
                      </span>
                    </div>
                  )}
                </div>

                <div className="border-t pt-4">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold">Итого:</span>
                    <span className="text-2xl font-bold text-primary">{calculatePrice()} ₽</span>
                  </div>
                </div>

                <div className="text-xs text-muted-foreground">* Срок изготовления: 1-2 рабочих дня</div>

                <Button className="w-full" disabled={calculatePrice() === 0}>
                  Заказать печать
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
