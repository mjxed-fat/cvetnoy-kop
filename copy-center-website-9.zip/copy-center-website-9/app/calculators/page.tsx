"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calculator, FileText, Monitor, CreditCard, Sticker, ArrowRight } from "lucide-react"
import Link from "next/link"

const calculators = [
  {
    id: "documents",
    icon: FileText,
    title: "Документы",
    description: "Расчет стоимости печати документов, копирования и переплета",
    features: ["Форматы A7-A0", "Черно-белая и цветная печать", "Различные типы бумаги", "Переплет и ламинация"],
    href: "/calculators/documents",
    popular: true,
  },
  {
    id: "large-format",
    icon: Monitor,
    title: "Широкоформат",
    description: "Калькулятор для баннеров, постеров и широкоформатной печати",
    features: ["Баннеры и постеры", "Печать на холсте", "Самоклеящаяся пленка", "POS-материалы"],
    href: "/calculators/wide-format",
    popular: true,
  },
  {
    id: "business-cards",
    icon: CreditCard,
    title: "Визитки / Листовки / Буклеты",
    description: "Расчет полиграфической продукции для бизнеса",
    features: ["Визитки разных форматов", "Листовки и флаеры", "Буклеты и брошюры", "Дизайнерская бумага"],
    href: "/calculators/business-cards",
    popular: true,
  },
  {
    id: "stickers",
    icon: Sticker,
    title: "Наклейки / Этикетки",
    description: "Калькулятор для наклеек, этикеток и стикеров",
    features: ["Печать на листах и рулонах", "Высечка по контуру", "Водостойкие материалы", "Фольгирование"],
    href: "/calculators/stickers",
    popular: false,
  },
]

export default function CalculatorsPage() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-br from-background via-background to-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`text-center space-y-6 ${isVisible ? "animate-fade-in-up" : "opacity-0"}`}>
            <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto">
              <Calculator className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground text-balance">
              Калькуляторы стоимости
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Рассчитайте стоимость печати онлайн за несколько секунд. Выберите нужный калькулятор и получите точную
              цену с учетом всех параметров заказа.
            </p>
          </div>
        </div>
      </section>

      {/* Calculators Grid */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div
            className={`grid grid-cols-1 md:grid-cols-2 gap-8 ${isVisible ? "animate-fade-in-up animate-delay-200" : "opacity-0"}`}
          >
            {calculators.map((calc, index) => {
              const Icon = calc.icon
              return (
                <Card
                  key={calc.id}
                  className="group hover:shadow-xl transition-all duration-300 border-0 bg-card/50 backdrop-blur-sm relative overflow-hidden"
                >
                  {calc.popular && (
                    <div className="absolute top-4 right-4 bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full font-medium">
                      Популярно
                    </div>
                  )}

                  <CardHeader className="pb-4">
                    <div className="flex items-start space-x-4">
                      <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                        <Icon className="w-7 h-7 text-primary" />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-xl group-hover:text-primary transition-colors">
                          {calc.title}
                        </CardTitle>
                        <p className="text-sm text-muted-foreground mt-2 text-pretty">{calc.description}</p>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-6">
                    <ul className="space-y-2">
                      {calc.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center space-x-2 text-sm">
                          <div className="w-1.5 h-1.5 bg-primary rounded-full"></div>
                          <span className="text-muted-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    <Button className="w-full group-hover:bg-primary/90 transition-colors" asChild>
                      <Link href={calc.href}>
                        Открыть калькулятор
                        <ArrowRight className="ml-2 w-4 h-4" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`text-center space-y-12 ${isVisible ? "animate-fade-in-up animate-delay-400" : "opacity-0"}`}>
            <div className="space-y-4">
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground text-balance">
                Почему наши калькуляторы удобны?
              </h2>
              <p className="text-lg text-muted-foreground text-pretty">
                Мы создали максимально простые и точные инструменты для расчета стоимости
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center space-y-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mx-auto">
                  <Calculator className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">Точный расчет</h3>
                <p className="text-sm text-muted-foreground text-pretty">
                  Учитываем все параметры: тираж, материал, постпечатную обработку
                </p>
              </div>

              <div className="text-center space-y-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mx-auto">
                  <ArrowRight className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">Быстрый результат</h3>
                <p className="text-sm text-muted-foreground text-pretty">
                  Получите стоимость за несколько секунд без звонков менеджеру
                </p>
              </div>

              <div className="text-center space-y-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mx-auto">
                  <FileText className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">Готовое предложение</h3>
                <p className="text-sm text-muted-foreground text-pretty">
                  Сохраните расчет и используйте для оформления заказа
                </p>
              </div>
            </div>

            <div className="pt-8">
              <Button size="lg" variant="outline" asChild>
                <Link href="/contacts">
                  Нужна консультация?
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
