"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { FileText, Calculator, Download, Send } from "lucide-react"

const paperTypes = [
  { id: "office", name: "Офисная бумага 80г", price: 3 },
  { id: "premium", name: "Премиум бумага 120г", price: 5 },
  { id: "photo", name: "Фотобумага глянцевая", price: 15 },
  { id: "photo-matte", name: "Фотобумага матовая", price: 15 },
]

const formats = [
  { id: "a4", name: "A4", multiplier: 1 },
  { id: "a3", name: "A3", multiplier: 2 },
  { id: "a2", name: "A2", multiplier: 4 },
  { id: "a1", name: "A1", multiplier: 8 },
  { id: "a0", name: "A0", multiplier: 16 },
]

const bindingTypes = [
  { id: "none", name: "Без переплета", price: 0 },
  { id: "spring", name: "Пружина", price: 50 },
  { id: "thermal", name: "Термопереплет", price: 80 },
  { id: "staple", name: "Скрепка", price: 10 },
]

export default function DocumentsCalculatorPage() {
  const [isVisible, setIsVisible] = useState(false)
  const [quantity, setQuantity] = useState(1)
  const [format, setFormat] = useState("a4")
  const [paperType, setPaperType] = useState("office")
  const [isColor, setIsColor] = useState(false)
  const [binding, setBinding] = useState("none")
  const [isLaminated, setIsLaminated] = useState(false)
  const [totalPrice, setTotalPrice] = useState(0)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  useEffect(() => {
    calculatePrice()
  }, [quantity, format, paperType, isColor, binding, isLaminated])

  const calculatePrice = () => {
    const selectedPaper = paperTypes.find((p) => p.id === paperType)
    const selectedFormat = formats.find((f) => f.id === format)
    const selectedBinding = bindingTypes.find((b) => b.id === binding)

    if (!selectedPaper || !selectedFormat || !selectedBinding) return

    let basePrice = selectedPaper.price * selectedFormat.multiplier
    if (isColor) basePrice *= 3
    if (isLaminated) basePrice += 20

    const printPrice = basePrice * quantity
    const bindingPrice = selectedBinding.price

    setTotalPrice(printPrice + bindingPrice)
  }

  return (
    <main className="min-h-screen">
      <Header />

      <section className="pt-24 pb-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`space-y-8 ${isVisible ? "animate-fade-in-up" : "opacity-0"}`}>
            {/* Header */}
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto">
                <FileText className="w-8 h-8 text-primary" />
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground">Калькулятор документов</h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
                Рассчитайте стоимость печати документов, копирования и переплета
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Calculator Form */}
              <div className="lg:col-span-2">
                <Card className="border-0 bg-card/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Calculator className="w-5 h-5 text-primary" />
                      <span>Параметры заказа</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="quantity">Количество листов</Label>
                        <Input
                          id="quantity"
                          type="number"
                          min="1"
                          value={quantity}
                          onChange={(e) => setQuantity(Math.max(1, Number.parseInt(e.target.value) || 1))}
                          className="text-lg"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="format">Формат</Label>
                        <Select value={format} onValueChange={setFormat}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {formats.map((f) => (
                              <SelectItem key={f.id} value={f.id}>
                                {f.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="paper">Тип бумаги</Label>
                        <Select value={paperType} onValueChange={setPaperType}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {paperTypes.map((p) => (
                              <SelectItem key={p.id} value={p.id}>
                                {p.name} - {p.price} ₽
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="binding">Переплет</Label>
                        <Select value={binding} onValueChange={setBinding}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {bindingTypes.map((b) => (
                              <SelectItem key={b.id} value={b.id}>
                                {b.name} {b.price > 0 && `- ${b.price} ₽`}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <Checkbox id="color" checked={isColor} onCheckedChange={setIsColor} />
                        <Label htmlFor="color" className="text-sm font-normal">
                          Цветная печать (+200% к стоимости)
                        </Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox id="lamination" checked={isLaminated} onCheckedChange={setIsLaminated} />
                        <Label htmlFor="lamination" className="text-sm font-normal">
                          Ламинирование (+20 ₽ за лист)
                        </Label>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Price Summary */}
              <div className="space-y-6">
                <Card className="border-0 bg-primary/5 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-primary">Итоговая стоимость</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-center">
                      <div className="text-4xl font-bold text-primary">{totalPrice} ₽</div>
                      <div className="text-sm text-muted-foreground mt-1">
                        {quantity > 1 && `≈ ${Math.round(totalPrice / quantity)} ₽ за лист`}
                      </div>
                    </div>

                    <div className="space-y-2 pt-4 border-t border-border">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Печать:</span>
                        <span>{totalPrice - (bindingTypes.find((b) => b.id === binding)?.price || 0)} ₽</span>
                      </div>
                      {binding !== "none" && (
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Переплет:</span>
                          <span>{bindingTypes.find((b) => b.id === binding)?.price} ₽</span>
                        </div>
                      )}
                    </div>

                    <div className="space-y-3 pt-4">
                      <Button className="w-full" size="lg">
                        <Send className="w-4 h-4 mr-2" />
                        Оформить заказ
                      </Button>
                      <Button variant="outline" className="w-full bg-transparent">
                        <Download className="w-4 h-4 mr-2" />
                        Скачать расчет
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 bg-card/50 backdrop-blur-sm">
                  <CardContent className="pt-6">
                    <div className="space-y-3 text-sm">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Время выполнения:</span>
                        <span className="font-medium">от 15 минут</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Срочность:</span>
                        <span className="font-medium">+50% к стоимости</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Доставка:</span>
                        <span className="font-medium">от 200 ₽</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
