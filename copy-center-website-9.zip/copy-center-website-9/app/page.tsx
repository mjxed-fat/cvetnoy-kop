import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { ServicesPreview } from "@/components/services-preview"
import { HowItWorks } from "@/components/how-it-works"
import { WorksGallery } from "@/components/works-gallery"
import { SalesAssistant } from "@/components/sales-assistant"
import { BranchesSection } from "@/components/branches-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <Header />
      <HeroSection />
      <ServicesPreview />
      <HowItWorks />
      <WorksGallery />
      <SalesAssistant />
      <BranchesSection />
      <Footer />
    </main>
  )
}
