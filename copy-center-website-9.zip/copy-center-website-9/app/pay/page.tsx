"use client"

import { useMemo } from "react"
import { useSearchParams } from "next/navigation"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { CreditCard, ArrowLeft } from "lucide-react"

export default function PayPage() {
  const params = useSearchParams()

  const summary = useMemo(() => {
    const entries: [string, string][] = []
    params.forEach((v, k) => entries.push([k, v]))
    return entries
  }, [params])

  return (
    <main className="min-h-screen">
      <Header />
      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <div className="space-y-2">
            <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight">Заявка и оплата</h1>
            <p className="text-muted-foreground">
              Это страница‑заготовка под онлайн‑оплату. Сюда можно подключить ЮKassa/CloudPayments/Stripe и принимать оплату
              по ссылке.
            </p>
          </div>

          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Детали заказа</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {summary.length ? (
                <div className="rounded-lg border p-4 text-sm">
                  <div className="font-medium mb-2">Передано из диалога</div>
                  <ul className="space-y-1 text-muted-foreground">
                    {summary.map(([k, v]) => (
                      <li key={k}>
                        <span className="font-medium text-foreground">{k}:</span> {v}
                      </li>
                    ))}
                  </ul>
                </div>
              ) : (
                <div className="rounded-lg border p-4 text-sm text-muted-foreground">
                  Параметры не переданы. Вернитесь на главную и заполните диалог.
                </div>
              )}

              <div className="rounded-lg border bg-muted/30 p-4 text-sm">
                <div className="font-medium">Как будет работать оплата</div>
                <ol className="list-decimal pl-5 mt-2 space-y-1 text-muted-foreground">
                  <li>ИИ‑помощник собирает параметры заказа</li>
                  <li>сервис рассчитывает стоимость (по прайсу + материалам + обработке)</li>
                  <li>клиент оплачивает онлайн</li>
                  <li>заказ уходит в работу, статус обновляется</li>
                </ol>
              </div>

              <div className="flex flex-col sm:flex-row gap-2">
                <Button disabled className="gap-2">
                  <CreditCard className="h-4 w-4" />
                  Оплатить (подключим позже)
                </Button>
                <Button asChild variant="outline" className="gap-2">
                  <Link href="/#assistant">
                    <ArrowLeft className="h-4 w-4" />
                    Вернуться к диалогу
                  </Link>
                </Button>
              </div>

              <p className="text-xs text-muted-foreground">
                Сейчас кнопка оплаты отключена намеренно: без подключения платёжного провайдера оплата невозможна.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>
      <Footer />
    </main>
  )
}
