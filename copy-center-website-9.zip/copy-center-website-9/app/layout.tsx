import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { Suspense } from "react"
import "./globals.css"
import { StickyMobileBar } from "@/components/sticky-mobile-bar"

const inter = Inter({
  subsets: ["latin", "cyrillic"],
  variable: "--font-inter",
  display: "swap",
})

export const metadata: Metadata = {
  title: "Цветной — Сеть копицентров и типографии",
  description: "Профессиональная печать, копирование, полиграфия и дизайн. Быстро, качественно, доступно.",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ru" className={inter.variable}>
      <body className="font-sans antialiased pb-16 md:pb-0">
        <Suspense fallback={<div>Loading...</div>}>{children}</Suspense>
        <StickyMobileBar />
        <Analytics />
      </body>
    </html>
  )
}
