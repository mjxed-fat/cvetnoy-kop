"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { User, FileText, CreditCard, Settings, Download, Eye, Clock, CheckCircle, XCircle } from "lucide-react"
import Link from "next/link"

const orders = [
  {
    id: "#2024-001",
    date: "15.01.2024",
    service: "Печать визиток",
    quantity: "1000 шт",
    status: "completed",
    total: "2 500 ₽",
    files: ["business-cards-design.pdf"],
  },
  {
    id: "#2024-002",
    date: "18.01.2024",
    service: "Широкоформатная печать",
    quantity: "2×3 м",
    status: "in-progress",
    total: "4 200 ₽",
    files: ["banner-design.ai"],
  },
  {
    id: "#2024-003",
    date: "20.01.2024",
    service: "Печать каталогов",
    quantity: "50 шт",
    status: "pending",
    total: "8 750 ₽",
    files: ["catalog-layout.pdf", "catalog-cover.jpg"],
  },
]

const statusConfig = {
  pending: { label: "Ожидает", color: "bg-yellow-100 text-yellow-800", icon: Clock },
  "in-progress": { label: "В работе", color: "bg-blue-100 text-blue-800", icon: Settings },
  completed: { label: "Выполнен", color: "bg-green-100 text-green-800", icon: CheckCircle },
  cancelled: { label: "Отменен", color: "bg-red-100 text-red-800", icon: XCircle },
}

export default function AccountPage() {
  const [activeTab, setActiveTab] = useState("orders")

  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-br from-background via-background to-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center">
              <User className="w-8 h-8 text-primary" />
            </div>
            <div>
              <h1 className="text-4xl sm:text-5xl font-bold text-foreground">Личный кабинет</h1>
              <p className="text-lg text-muted-foreground">Управляйте заказами и настройками</p>
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="orders" className="gap-2">
                <FileText className="w-4 h-4" />
                Заказы
              </TabsTrigger>
              <TabsTrigger value="profile" className="gap-2">
                <User className="w-4 h-4" />
                Профиль
              </TabsTrigger>
              <TabsTrigger value="payments" className="gap-2">
                <CreditCard className="w-4 h-4" />
                Платежи
              </TabsTrigger>
              <TabsTrigger value="settings" className="gap-2">
                <Settings className="w-4 h-4" />
                Настройки
              </TabsTrigger>
            </TabsList>

            {/* Orders Tab */}
            <TabsContent value="orders" className="mt-8">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold">Мои заказы</h2>
                  <Button asChild>
                    <Link href="/calculators">
                      <FileText className="w-4 h-4 mr-2" />
                      Новый заказ
                    </Link>
                  </Button>
                </div>

                <div className="grid gap-4">
                  {orders.map((order) => {
                    const StatusIcon = statusConfig[order.status].icon
                    return (
                      <Card key={order.id} className="hover:shadow-lg transition-all duration-300">
                        <CardHeader>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <CardTitle className="text-lg">{order.id}</CardTitle>
                              <Badge className={statusConfig[order.status].color}>
                                <StatusIcon className="w-3 h-3 mr-1" />
                                {statusConfig[order.status].label}
                              </Badge>
                            </div>
                            <span className="text-sm text-muted-foreground">{order.date}</span>
                          </div>
                          <CardDescription>
                            {order.service} • {order.quantity}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="flex items-center justify-between">
                            <div className="space-y-2">
                              <div className="text-sm text-muted-foreground">Файлы:</div>
                              <div className="flex flex-wrap gap-2">
                                {order.files.map((file, index) => (
                                  <Button key={index} variant="outline" size="sm" className="gap-2 bg-transparent">
                                    <Eye className="w-3 h-3" />
                                    {file}
                                  </Button>
                                ))}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-2xl font-bold text-primary">{order.total}</div>
                              <Button variant="outline" size="sm" className="mt-2 gap-2 bg-transparent">
                                <Download className="w-3 h-3" />
                                Скачать
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              </div>
            </TabsContent>

            {/* Profile Tab */}
            <TabsContent value="profile" className="mt-8">
              <Card>
                <CardHeader>
                  <CardTitle>Информация профиля</CardTitle>
                  <CardDescription>Управляйте своими личными данными и контактной информацией</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">Имя</Label>
                      <Input id="firstName" placeholder="Введите имя" defaultValue="Александр" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Фамилия</Label>
                      <Input id="lastName" placeholder="Введите фамилию" defaultValue="Петров" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="email@example.com"
                      defaultValue="a.petrov@example.com"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Телефон</Label>
                    <Input id="phone" placeholder="+7 (999) 123-45-67" defaultValue="+7 (999) 123-45-67" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="company">Компания</Label>
                    <Input id="company" placeholder="Название компании" defaultValue="ООО Пример" />
                  </div>

                  <Button className="w-full md:w-auto">Сохранить изменения</Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Payments Tab */}
            <TabsContent value="payments" className="mt-8">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Способы оплаты</CardTitle>
                    <CardDescription>Управляйте своими способами оплаты</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <CreditCard className="w-5 h-5 text-muted-foreground" />
                          <div>
                            <div className="font-medium">•••• •••• •••• 1234</div>
                            <div className="text-sm text-muted-foreground">Expires 12/26</div>
                          </div>
                        </div>
                        <Badge>Основная</Badge>
                      </div>
                      <Button variant="outline" className="w-full gap-2 bg-transparent">
                        <CreditCard className="w-4 h-4" />
                        Добавить карту
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>История платежей</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {orders
                        .filter((order) => order.status === "completed")
                        .map((order) => (
                          <div key={order.id} className="flex items-center justify-between py-2">
                            <div>
                              <div className="font-medium">{order.id}</div>
                              <div className="text-sm text-muted-foreground">{order.date}</div>
                            </div>
                            <div className="text-right">
                              <div className="font-medium">{order.total}</div>
                              <div className="text-sm text-green-600">Оплачено</div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="mt-8">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Уведомления</CardTitle>
                    <CardDescription>Настройте, какие уведомления вы хотите получать</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Email уведомления</div>
                        <div className="text-sm text-muted-foreground">Получать уведомления о статусе заказов</div>
                      </div>
                      <Button variant="outline" size="sm">
                        Включено
                      </Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">SMS уведомления</div>
                        <div className="text-sm text-muted-foreground">Получать SMS о готовности заказов</div>
                      </div>
                      <Button variant="outline" size="sm">
                        Выключено
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Безопасность</CardTitle>
                    <CardDescription>Управляйте настройками безопасности аккаунта</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                      Изменить пароль
                    </Button>
                    <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                      Двухфакторная аутентификация
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      <Footer />
    </main>
  )
}
