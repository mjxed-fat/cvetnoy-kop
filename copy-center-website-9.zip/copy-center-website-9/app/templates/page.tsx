"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Download, Search, FileText, ImageIcon, Layout, Palette, ArrowRight } from "lucide-react"
import Link from "next/link"

const templates = [
  {
    id: 1,
    title: "Визитки классические",
    category: "Визитки",
    format: "90×50 мм",
    description: "Элегантные шаблоны визиток для бизнеса",
    downloads: 1250,
    image: "/business-card-template.png",
    tags: ["Бизнес", "Классика", "Минимализм"],
  },
  {
    id: 2,
    title: "Листовки акционные",
    category: "Листовки",
    format: "A4",
    description: "Яркие шаблоны для рекламных акций",
    downloads: 890,
    image: "/promotional-flyer-template.jpg",
    tags: ["Акции", "Реклама", "Яркие"],
  },
  {
    id: 3,
    title: "Буклеты корпоративные",
    category: "Буклеты",
    format: "A4 (3 фальца)",
    description: "Профессиональные шаблоны буклетов",
    downloads: 670,
    image: "/corporate-brochure-template.jpg",
    tags: ["Корпоратив", "Презентация", "Бизнес"],
  },
  {
    id: 4,
    title: "Календари настольные",
    category: "Календари",
    format: "210×150 мм",
    description: "Стильные календари на 2024 год",
    downloads: 540,
    image: "/desk-calendar-template.jpg",
    tags: ["2024", "Настольные", "Офис"],
  },
  {
    id: 5,
    title: "Этикетки продуктовые",
    category: "Этикетки",
    format: "Различные",
    description: "Шаблоны этикеток для продуктов",
    downloads: 780,
    image: "/product-label-template.jpg",
    tags: ["Продукты", "Этикетки", "Упаковка"],
  },
  {
    id: 6,
    title: "Баннеры интерьерные",
    category: "Баннеры",
    format: "1×2 м",
    description: "Шаблоны для интерьерной рекламы",
    downloads: 320,
    image: "/interior-banner-template.jpg",
    tags: ["Интерьер", "Реклама", "Большой формат"],
  },
]

const categories = ["Все", "Визитки", "Листовки", "Буклеты", "Календари", "Этикетки", "Баннеры"]

const instructions = [
  {
    title: "Подготовка файлов к печати",
    description: "Как правильно подготовить макет для качественной печати",
    icon: FileText,
    steps: [
      "Разрешение не менее 300 dpi",
      "Цветовая модель CMYK",
      "Добавить вылеты 3-5 мм",
      "Проверить шрифты и изображения",
    ],
  },
  {
    title: "Требования к изображениям",
    description: "Технические требования к графическим файлам",
    icon: ImageIcon,
    steps: [
      "Формат: PDF, AI, PSD, TIFF",
      "Минимальное разрешение 300 dpi",
      "Размер изображений до 100 МБ",
      "Избегать RGB и веб-цветов",
    ],
  },
  {
    title: "Работа с макетами",
    description: "Правила создания и редактирования макетов",
    icon: Layout,
    steps: [
      "Использовать направляющие",
      "Соблюдать отступы от краев",
      "Проверить читаемость текста",
      "Сохранить в нужном формате",
    ],
  },
  {
    title: "Цветопередача",
    description: "Как добиться точной передачи цветов при печати",
    icon: Palette,
    steps: [
      "Использовать цветовые профили",
      "Избегать чистого черного (0,0,0,100)",
      "Проверить на цветопробе",
      "Учитывать тип бумаги",
    ],
  },
]

export default function TemplatesPage() {
  const [selectedCategory, setSelectedCategory] = useState("Все")
  const [searchQuery, setSearchQuery] = useState("")

  const filteredTemplates = templates.filter((template) => {
    const matchesCategory = selectedCategory === "Все" || template.category === selectedCategory
    const matchesSearch =
      template.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))
    return matchesCategory && matchesSearch
  })

  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-br from-background via-background to-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground text-balance">
              Шаблоны и инструкции
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Готовые шаблоны для быстрого создания макетов и подробные инструкции по подготовке файлов к печати
            </p>
          </div>
        </div>
      </section>

      {/* Templates Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-foreground mb-8">Готовые шаблоны</h2>

          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Поиск шаблонов..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category)}
                  className="whitespace-nowrap"
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>

          {/* Templates Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
            {filteredTemplates.map((template) => (
              <Card key={template.id} className="group hover:shadow-lg transition-all duration-300">
                <div className="aspect-[3/2] overflow-hidden rounded-t-lg">
                  <img
                    src={`/.jpg?key=g6tgd&height=200&width=300&query=${encodeURIComponent(template.title)}`}
                    alt={template.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="secondary">{template.category}</Badge>
                    <span className="text-sm text-muted-foreground">{template.format}</span>
                  </div>
                  <CardTitle className="text-lg">{template.title}</CardTitle>
                  <CardDescription>{template.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-1 mb-4">
                    {template.tags.map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">{template.downloads} скачиваний</span>
                    <Button size="sm" className="gap-2">
                      <Download className="w-4 h-4" />
                      Скачать
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Instructions Section */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-foreground mb-8 text-center">Инструкции по подготовке</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {instructions.map((instruction, index) => (
              <Card key={index} className="hover:shadow-lg transition-all duration-300">
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <instruction.icon className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle className="text-xl">{instruction.title}</CardTitle>
                  </div>
                  <CardDescription>{instruction.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {instruction.steps.map((step, stepIndex) => (
                      <li key={stepIndex} className="flex items-start gap-2">
                        <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                        <span className="text-sm text-muted-foreground">{step}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-foreground mb-4">Нужна помощь с макетом?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Наши дизайнеры помогут создать уникальный макет или адаптировать готовый шаблон
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/services#design">
                Заказать дизайн
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/contacts">Консультация</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
