"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MessageCircle, Calendar, User, ArrowRight, Clock, Eye } from "lucide-react"
import Link from "next/link"

const blogPosts = [
  {
    id: 1,
    title: "Как выбрать правильную бумагу для печати визиток",
    excerpt:
      "Разбираем виды бумаги, их особенности и влияние на восприятие вашего бренда. Практические советы от экспертов.",
    content: "Полное руководство по выбору бумаги для визиток...",
    author: "Анна Петрова",
    date: "2024-01-15",
    readTime: "5 мин",
    views: 1247,
    category: "Советы",
    tags: ["Визитки", "Бумага", "Дизайн"],
    image: "/blog-business-cards-paper.jpg",
    featured: true,
  },
  {
    id: 2,
    title: "Тренды полиграфии 2024: что будет популярно",
    excerpt: "Обзор главных трендов в полиграфии: от экологичных материалов до интерактивных элементов в печати.",
    content: "Анализ трендов полиграфии на 2024 год...",
    author: "Михаил Сидоров",
    date: "2024-01-10",
    readTime: "7 мин",
    views: 892,
    category: "Тренды",
    tags: ["Тренды", "Полиграфия", "2024"],
    image: "/blog-printing-trends-2024.jpg",
    featured: false,
  },
  {
    id: 3,
    title: "Подготовка макетов к печати: чек-лист дизайнера",
    excerpt: "Пошаговое руководство по подготовке файлов к печати. Избегайте ошибок и получайте идеальный результат.",
    content: "Детальный чек-лист для подготовки макетов...",
    author: "Елена Козлова",
    date: "2024-01-05",
    readTime: "6 мин",
    views: 1156,
    category: "Инструкции",
    tags: ["Дизайн", "Препресс", "Макеты"],
    image: "/blog-design-checklist.jpg",
    featured: true,
  },
  {
    id: 4,
    title: "Широкоформатная печать: материалы и их применение",
    excerpt: "Обзор материалов для широкоформатной печати: от баннерной ткани до самоклеящейся пленки.",
    content: "Подробный обзор материалов для широкоформата...",
    author: "Дмитрий Волков",
    date: "2023-12-28",
    readTime: "8 мин",
    views: 743,
    category: "Материалы",
    tags: ["Широкоформат", "Материалы", "Баннеры"],
    image: "/blog-large-format-materials.jpg",
    featured: false,
  },
  {
    id: 5,
    title: "Постпечатная обработка: виды и возможности",
    excerpt: "Ламинация, тиснение, высечка и другие способы сделать вашу полиграфию особенной.",
    content: "Полный гид по постпечатной обработке...",
    author: "Ольга Морозова",
    date: "2023-12-20",
    readTime: "9 мин",
    views: 634,
    category: "Технологии",
    tags: ["Постпечать", "Ламинация", "Тиснение"],
    image: "/blog-post-print-processing.jpg",
    featured: false,
  },
  {
    id: 6,
    title: "Цветопередача в печати: от монитора к бумаге",
    excerpt: "Почему цвета на экране отличаются от печатных и как добиться точной цветопередачи.",
    content: "Разбираем вопросы цветопередачи в печати...",
    author: "Игорь Белов",
    date: "2023-12-15",
    readTime: "6 мин",
    views: 987,
    category: "Технологии",
    tags: ["Цвет", "Печать", "Калибровка"],
    image: "/blog-color-accuracy.jpg",
    featured: false,
  },
]

const categories = ["Все", "Советы", "Тренды", "Инструкции", "Материалы", "Технологии"]

export default function BlogPage() {
  const [isVisible, setIsVisible] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState("Все")
  const [filteredPosts, setFilteredPosts] = useState(blogPosts)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  useEffect(() => {
    if (selectedCategory === "Все") {
      setFilteredPosts(blogPosts)
    } else {
      setFilteredPosts(blogPosts.filter((post) => post.category === selectedCategory))
    }
  }, [selectedCategory])

  const featuredPosts = blogPosts.filter((post) => post.featured)
  const regularPosts = filteredPosts.filter((post) => !post.featured)

  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-br from-background via-background to-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`text-center space-y-6 ${isVisible ? "animate-fade-in-up" : "opacity-0"}`}>
            <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto">
              <MessageCircle className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground text-balance">Блог о печати</h1>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Полезные статьи о полиграфии, дизайне и печати. Советы экспертов, обзоры материалов и актуальные тренды
              индустрии.
            </p>
          </div>
        </div>
      </section>

      {/* Featured Posts */}
      {selectedCategory === "Все" && (
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className={`space-y-8 ${isVisible ? "animate-fade-in-up animate-delay-200" : "opacity-0"}`}>
              <h2 className="text-2xl font-bold text-foreground">Рекомендуем прочитать</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {featuredPosts.slice(0, 2).map((post, index) => (
                  <Card
                    key={post.id}
                    className="group hover:shadow-xl transition-all duration-300 border-0 bg-card/50 backdrop-blur-sm overflow-hidden"
                  >
                    <div className="relative overflow-hidden">
                      <img
                        src={post.image || "/placeholder.svg"}
                        alt={post.title}
                        className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <Badge className="absolute top-4 left-4 bg-primary text-primary-foreground">
                        {post.category}
                      </Badge>
                    </div>

                    <CardHeader className="pb-4">
                      <div className="space-y-3">
                        <h3 className="text-xl font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-2">
                          {post.title}
                        </h3>
                        <p className="text-muted-foreground text-pretty line-clamp-2">{post.excerpt}</p>
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-1">
                            <User className="w-3 h-3" />
                            <span>{post.author}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Calendar className="w-3 h-3" />
                            <span>{new Date(post.date).toLocaleDateString("ru-RU")}</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center space-x-1">
                            <Clock className="w-3 h-3" />
                            <span>{post.readTime}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Eye className="w-3 h-3" />
                            <span>{post.views}</span>
                          </div>
                        </div>
                      </div>

                      <Button variant="ghost" className="w-full justify-between p-0 h-auto text-primary" asChild>
                        <Link href={`/blog/${post.id}`}>
                          Читать далее
                          <ArrowRight className="w-4 h-4" />
                        </Link>
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Filter Section */}
      <section className="py-8 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div
            className={`flex items-center space-x-4 ${isVisible ? "animate-fade-in-up animate-delay-300" : "opacity-0"}`}
          >
            <span className="text-sm font-medium text-foreground">Категории:</span>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className={selectedCategory !== category ? "bg-transparent" : ""}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* All Posts */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div
            className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 ${isVisible ? "animate-fade-in-up animate-delay-400" : "opacity-0"}`}
          >
            {(selectedCategory === "Все" ? regularPosts : filteredPosts).map((post, index) => (
              <Card
                key={post.id}
                className="group hover:shadow-xl transition-all duration-300 border-0 bg-card/50 backdrop-blur-sm overflow-hidden"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={post.image || "/placeholder.svg"}
                    alt={post.title}
                    className="w-full h-40 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <Badge className="absolute top-3 left-3 bg-primary text-primary-foreground text-xs">
                    {post.category}
                  </Badge>
                </div>

                <CardContent className="p-6 space-y-4">
                  <div className="space-y-2">
                    <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-2">
                      {post.title}
                    </h3>
                    <p className="text-sm text-muted-foreground text-pretty line-clamp-3">{post.excerpt}</p>
                  </div>

                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center space-x-2">
                      <span>{post.author}</span>
                      <span>•</span>
                      <span>{new Date(post.date).toLocaleDateString("ru-RU")}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="w-3 h-3" />
                      <span>{post.readTime}</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {post.tags.slice(0, 2).map((tag, tagIndex) => (
                      <Badge key={tagIndex} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <Button variant="ghost" className="w-full justify-between p-0 h-auto text-primary" asChild>
                    <Link href={`/blog/${post.id}`}>
                      Читать
                      <ArrowRight className="w-3 h-3" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
