import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { BRANCHES } from "@/lib/site-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MapPin, Clock, Phone } from "lucide-react"

export default function BranchesPage() {
  return (
    <main className="min-h-screen">
      <Header />
      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="space-y-2">
            <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight">Филиалы</h1>
            <p className="text-muted-foreground">
              Выберите удобный филиал.</p>
          </div>

          <div className="mt-8 grid gap-6 lg:grid-cols-3">
            {BRANCHES.map((b) => (
              <Card key={b.id} className="h-full">
                <CardHeader>
                  <CardTitle className="text-lg">{b.name}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2 text-sm">
                    <div className="flex gap-2">
                      <MapPin className="h-4 w-4 mt-0.5 text-muted-foreground" />
                      <div>{b.address}</div>
                    </div>
                    <div className="flex gap-2">
                      <Clock className="h-4 w-4 mt-0.5 text-muted-foreground" />
                      <div>{b.hours}</div>
                    </div>
                    <div className="flex gap-2">
                      <Phone className="h-4 w-4 mt-0.5 text-muted-foreground" />
                      <div>{b.phone}</div>
                    </div>
                  </div>

                  <div>
                    <div className="text-sm font-medium mb-2">Что делаем в этом филиале</div>
                    <ul className="list-disc pl-5 text-sm text-muted-foreground space-y-1">
                      {b.features.map((f) => (
                        <li key={f}>{f}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex flex-col gap-2">
                    <Button asChild variant="outline">
                      <a href={b.yandexMapsUrl} target="_blank" rel="noreferrer">
                        Открыть в Яндекс.Картах
                      </a>
                    </Button>
                    {b.gis2Url && (
                      <Button asChild variant="outline">
                        <a href={b.gis2Url} target="_blank" rel="noreferrer">
                          Открыть в 2ГИС
                        </a>
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
