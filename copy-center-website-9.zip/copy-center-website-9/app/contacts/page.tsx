"use client"

import { useMemo, useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { BRANCHES, COMPANY } from "@/lib/site-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Mail, Phone, MapPin, ArrowRight } from "lucide-react"

export default function ContactsPage() {
  const [branchId, setBranchId] = useState(BRANCHES[0]?.id)
  const [name, setName] = useState("")
  const [contact, setContact] = useState("")
  const [message, setMessage] = useState("")
  const [fileLink, setFileLink] = useState("")

  const branch = useMemo(() => BRANCHES.find((b) => b.id === branchId), [branchId])

  const mailto = useMemo(() => {
    const to = (branch?.email || COMPANY.emails[0]).trim()
    const subject = encodeURIComponent("Запрос на печать / расчёт заказа")
    const body = encodeURIComponent(
      [
        `Имя: ${name || "-"}`,
        `Контакт: ${contact || "-"}`,
        `Филиал: ${branch?.address || "-"}`,
        fileLink ? `Ссылка на файлы: ${fileLink}` : "",
        "",
        message || "",
      ]
        .filter(Boolean)
        .join("\n")
    )
    return `mailto:${to}?subject=${subject}&body=${body}`
  }, [branch, contact, fileLink, message, name])

  return (
    <main className="min-h-screen">
      <Header />
      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="space-y-2">
            <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight">Контакты</h1>
            <p className="text-muted-foreground">
              Уточним детали, проверим файл и дадим точный расчёт. Быстрый вариант —{" "}
              <a className="underline underline-offset-4" href="/#assistant">
                онлайн‑диалог
              </a>
              .
            </p>
          </div>

          <div className="mt-8 grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Связаться</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <div className="flex gap-2">
                  <Phone className="h-4 w-4 mt-0.5 text-muted-foreground" />
                  <a className="underline underline-offset-4" href={`tel:${COMPANY.phone.replace(/[^+\d]/g, "")}`}>
                    {COMPANY.phone}
                  </a>
                </div>
                <div className="flex gap-2">
                  <Mail className="h-4 w-4 mt-0.5 text-muted-foreground" />
                  <div className="text-muted-foreground">{COMPANY.emails.join(" • ")}</div>
                </div>

                <div className="rounded-lg border bg-muted/30 p-4">
                  <div className="font-medium">Онлайн‑оплата</div>
                  <p className="text-muted-foreground mt-1">
                    Оплата на сайте планируется через платёжный модуль. Сейчас кнопка «Оплата» ведёт на страницу‑заготовку,
                    которую можно подключить к ЮKassa/CloudPayments/Stripe.
                  </p>
                </div>

                <div className="rounded-lg border bg-background p-4">
                  <div className="font-medium">Филиалы</div>
                  <div className="mt-3 space-y-3">
                    {BRANCHES.map((b) => (
                      <a key={b.id} className="block" href={b.yandexMapsUrl} target="_blank" rel="noreferrer">
                        <div className="flex gap-2">
                          <MapPin className="h-4 w-4 mt-0.5 text-muted-foreground" />
                          <div>
                            <div className="font-medium">{b.name}</div>
                            <div className="text-muted-foreground">{b.address}</div>
                            <div className="text-muted-foreground">{b.hours}</div>
                          </div>
                        </div>
                      </a>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Быстрая заявка</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid gap-2">
                  <label className="text-sm font-medium">Выберите филиал</label>
                  <Select value={branchId} onValueChange={setBranchId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Филиал" />
                    </SelectTrigger>
                    <SelectContent>
                      {BRANCHES.map((b) => (
                        <SelectItem key={b.id} value={b.id}>
                          {b.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <label className="text-sm font-medium">Имя</label>
                  <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Как к вам обращаться" />
                </div>

                <div className="grid gap-2">
                  <label className="text-sm font-medium">Контакт</label>
                  <Input
                    value={contact}
                    onChange={(e) => setContact(e.target.value)}
                    placeholder="Телефон или мессенджер"
                  />
                </div>

                <div className="grid gap-2">
                  <label className="text-sm font-medium">Ссылка на файлы</label>
                  <Input
                    value={fileLink}
                    onChange={(e) => setFileLink(e.target.value)}
                    placeholder="Google Drive / Я.Диск / др."
                  />
                </div>

                <div className="grid gap-2">
                  <label className="text-sm font-medium">Комментарий</label>
                  <Textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Что нужно сделать, тираж, формат, срочность…"
                  />
                </div>

                <div className="flex flex-col sm:flex-row gap-2">
                  <Button asChild className="gap-2">
                    <a href={mailto}>
                      Отправить письмо <ArrowRight className="h-4 w-4" />
                    </a>
                  </Button>
                  <Button asChild variant="outline">
                    <a href="/#assistant">Онлайн‑расчёт</a>
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Письмо откроется в вашей почте с уже заполненными полями — это удобно без регистрации и бэкенда.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
