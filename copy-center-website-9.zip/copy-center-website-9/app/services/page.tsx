"use client"

import { useMemo, useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { SERVICES, type ServiceTag } from "@/lib/site-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { ArrowRight, Search } from "lucide-react"

const TAGS: ServiceTag[] = [
  "Документы",
  "Фото",
  "Полиграфия",
  "Наклейки",
  "Широкоформат",
  "Плоттерная резка",
  "Сублимация",
  "Дизайн",
  "Для бизнеса",
]

export default function ServicesPage() {
  const [q, setQ] = useState("")
  const [tag, setTag] = useState<ServiceTag | "Все">("Все")

  const items = useMemo(() => {
    const query = q.trim().toLowerCase()
    return SERVICES.filter((s) => {
      const tagOk = tag === "Все" ? true : s.tags.includes(tag)
      const qOk =
        !query ||
        s.title.toLowerCase().includes(query) ||
        s.short.toLowerCase().includes(query) ||
        s.tags.some((t) => t.toLowerCase().includes(query))
      return tagOk && qOk
    })
  }, [q, tag])

  return (
    <main className="min-h-screen">
      <Header />
      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
            <div className="space-y-2">
              <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight">Услуги</h1>
              <p className="text-muted-foreground">
                Мы не перегружаем прайс “таблицами”. Лучше — быстрый опрос:{" "}
                <a className="underline underline-offset-4" href="/#assistant">
                  онлайн‑диалог
                </a>
                .
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-2">
              <Button asChild className="gap-2">
                <a href="/#assistant">
                  Рассчитать онлайн <ArrowRight className="h-4 w-4" />
                </a>
              </Button>
              <Button asChild variant="outline">
                <Link href="/branches">Выбрать филиал</Link>
              </Button>
            </div>
          </div>

          <div className="mt-8 grid gap-3 lg:grid-cols-[1fr_auto]">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input className="pl-9" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск по услугам…" />
            </div>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant={tag === "Все" ? "default" : "outline"} onClick={() => setTag("Все")}>
                Все
              </Button>
              {TAGS.map((t) => (
                <Button
                  key={t}
                  size="sm"
                  variant={tag === t ? "default" : "outline"}
                  onClick={() => setTag(t)}
                >
                  {t}
                </Button>
              ))}
            </div>
          </div>

          <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {items.map((s) => (
              <Card key={s.id} className="h-full">
                <CardHeader>
                  <CardTitle className="text-lg">{s.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">{s.short}</p>
                  <div className="flex flex-wrap gap-2">
                    {s.tags.map((t) => (
                      <Badge key={t} variant="secondary">
                        {t}
                      </Badge>
                    ))}
                  </div>
                  <ul className="list-disc pl-5 text-sm text-muted-foreground space-y-1">
                    {s.notes.map((n) => (
                      <li key={n}>{n}</li>
                    ))}
                  </ul>

                  <Button asChild variant="outline" className="w-full gap-2">
                    <a
                      href={`/pay?service=${encodeURIComponent(s.title)}`}
                      title="Перейти к заявке/оплате (страница-заготовка)"
                    >
                      Заявка / оплата <ArrowRight className="h-4 w-4" />
                    </a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-10 rounded-xl border bg-muted/30 p-6">
            <div className="font-semibold">Как формируется цена</div>
            <p className="text-sm text-muted-foreground mt-2">
              Итог зависит от файла (качество, вылеты, поля), материала, тиража, срочности и послепечатной обработки.
              Поэтому вместо перегруженного калькулятора — диалоговый помощник: быстро уточняем детали и считаем точно.
            </p>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
